# Console Port Templates

A template for a console port that will be created on all instantiations of the parent device type. See the [console port](./consoleport.md) documentation for more detail.
