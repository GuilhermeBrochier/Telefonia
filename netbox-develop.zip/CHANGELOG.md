The changelog has been moved to the [project release notes](https://docs.netbox.dev/en/stable/release-notes/).
